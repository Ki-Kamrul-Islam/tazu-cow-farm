import { useState } from "react";

import stockAdjustmentService from "../services/stockAdjustmentService";

const initialForm = {
    inventoryItemId: "",
    type: "increase",
    quantity: "",
    reason: "",
    notes: "",
    date: new Date().toISOString().split("T")[0],
};

export default function useStockAdjustmentForm() {
    const [form, setForm] = useState(initialForm);

    const [loading, setLoading] = useState(false);

    const [error, setError] = useState("");

    const [success, setSuccess] = useState("");

    function handleChange(event) {
        const { name, value } = event.target;

        setForm((previous) => ({
            ...previous,
            [name]: value,
        }));

        setError("");
        setSuccess("");
    }

    async function submit(event) {
        event.preventDefault();

        setLoading(true);
        setError("");
        setSuccess("");

        try {
            stockAdjustmentService.createAdjustment(form);

            setSuccess("Stock adjustment created successfully.");

            setForm(initialForm);
        } catch (error) {
            setError(error.message || "Something went wrong.");
        } finally {
            setLoading(false);
        }
    }

    return {
        form,
        loading,
        error,
        success,
        handleChange,
        submit,
    };
}
